//
//  AppDelegate.h
//  myDragnWarrior
//
//  Created by jin on 2020/6/29.
//  Copyright © 2020 jin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

