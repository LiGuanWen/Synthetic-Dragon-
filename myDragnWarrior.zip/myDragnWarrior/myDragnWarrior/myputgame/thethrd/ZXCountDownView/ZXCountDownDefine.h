//
//  ZXCountDownDefine.h
//  ZXCountDownView
//
//  Created by 李兆祥 on 2019/2/15.
//  Copyright © 2019 李兆祥. All rights reserved.
//  https://github.com/SmileZXLee/ZXCountDownView

#ifndef ZXCountDownDefine_h
#define ZXCountDownDefine_h
#define ZXCountDownWeakSelf __weak __typeof(self) weakSelf = self
#define ZXCountDownBtnMark @"ZXCountDownBtnMark"
#endif /* ZXCountDownDefine_h */
