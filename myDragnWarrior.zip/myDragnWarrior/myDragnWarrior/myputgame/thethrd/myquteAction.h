//
//  myquteAction.h
//  FanBi
//
//  Created by jin on 2020/6/10.
//  Copyright © 2020 zhangjin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "myputView.h"

NS_ASSUME_NONNULL_BEGIN

@interface myquteAction : NSObject

+ (UIImage *)getmyImageDragnbylevel:(NSInteger)mylevel;

@end

NS_ASSUME_NONNULL_END
